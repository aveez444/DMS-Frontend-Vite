import React, { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { login } from "../api/auth";
import { useNavigate } from "react-router-dom";

const LoginModal = ({ closeModal }) => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const { login: setAuthUser } = useContext(AuthContext);
    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();
        if (!username || !password) {
            setError("Username and password are required");
            return;
        }

        setError("");
        setIsLoading(true);

        try {
            const authData = await login(username, password);
            console.log("Login successful, authData:", authData);
            setAuthUser(authData);
            closeModal();
            navigate(`/dashboard/${authData.user.uuid}`);
        } catch (err) {
            setError(err.response?.data?.error || "Login failed. Please try again.");
            setIsLoading(false);
        }
    };
    
    return (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-900 bg-opacity-50 z-50">
            <div className="bg-white p-6 rounded shadow-lg w-96">
                <h2 className="text-xl font-bold mb-4">Login</h2>
                {error && <p className="text-red-500 mb-4">{error}</p>}
                <form onSubmit={handleLogin}>
                    <input
                        type="text"
                        placeholder="Username"
                        className="w-full p-2 border mb-2 rounded"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        className="w-full p-2 border mb-2 rounded"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <div className="flex justify-between items-center">
                        <button
                            type="submit"
                            disabled={isLoading}
                            className="bg-blue-500 text-white px-4 py-2 rounded disabled:bg-blue-300"
                        >
                            {isLoading ? "Logging in..." : "Login"}
                        </button>
                        <button
                            type="button"
                            onClick={closeModal}
                            disabled={isLoading}
                            className="text-gray-600 disabled:text-gray-400"
                        >
                            Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default LoginModal;