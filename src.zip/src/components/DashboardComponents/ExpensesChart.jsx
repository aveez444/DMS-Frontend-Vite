import React from 'react'

const ExpensesChart = () => {
  return (
    <div>
      
    </div>
  )
}

export default ExpensesChart
