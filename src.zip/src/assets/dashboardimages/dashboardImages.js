import smallHome from "./smallhome.png";
import smallInventory from "./smallfile.png";
import smallTeam from "./smallteam.png";
import smallMaintenance from "./smallmaintenance.png";
import smallSales from "./smallsales.png";
import smallSettings from "./smallsettings.png";
import smallHelp from "./smallhelp.png";
import carlogo from "./carlogo.png";
import bus from "./bus.png"
import loaders from "./loaders.png"
import truck from "./truck.png"

const dashboardImages = {
  smallHome,
  smallInventory,
  smallTeam,
  smallMaintenance,
  smallSales,
  smallSettings,
  smallHelp,
  carlogo,
  bus,
  loaders,
  truck,
};

export default dashboardImages;
