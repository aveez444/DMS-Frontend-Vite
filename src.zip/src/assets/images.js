import landingpage1 from "./landingpage1.png";
import landingpage2 from "./landingpage2.png";
import landingpage3 from "./landingpage3.png";
import bggradient from "./bggradient.png";
import aboutimg from "./aboutimg.png";
import picture1 from "./picture1.png"
import picture2 from "./picture2.png"
import picture3 from "./picture3.png"
import picture4 from "./picture4.png"
import picture5 from "./picture5.png"
import picture6 from "./picture6.png"
import picture7 from "./picture7.png"
import picture8 from "./picture8.png"
import picture9 from "./picture9.png"
import picture10 from "./picture10.png"
import getstartedbg from "./getstartedbg.png"

const images = {
  landingpage1,
  landingpage2,
  landingpage3,
  bggradient,
  aboutimg,
  picture1,
  picture2,
  picture3,
  picture4,
  picture5,
  picture6,
  picture7,
  picture8,
  picture9,
  picture10,
  getstartedbg,

  

};

export default images;
