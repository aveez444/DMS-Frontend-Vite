import React from 'react'

const page6 = () => {
  return (
    <div>
      
    </div>
  )
}

export default page6
